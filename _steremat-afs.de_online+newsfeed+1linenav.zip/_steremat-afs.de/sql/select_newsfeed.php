<?php

// Select all Posts of Newsfeed

$sel1 = $db->selectNewsfeed();

?>