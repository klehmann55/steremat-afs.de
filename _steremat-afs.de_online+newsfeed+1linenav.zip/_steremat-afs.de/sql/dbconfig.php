<?php
// Database configuration
	$dbms = "mysql";
	$host = "80.81.241.58";
	$port = "3306";
	$dbname = "DB33916";
	$username = "steremat-afs.de";
	$password = "root_2017";

	// $dbms = "mysql";
	// $host = "localhost";
	// $port = "3306";
	// $dbname = "DB33916";
	// $username = "root";
	// $password = "";

// Check connection
// if ($db->connect_error) {
//     die("Connection failed: " . $db->connect_error);
// }